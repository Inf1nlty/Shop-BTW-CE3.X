package com.inf1nlty.shop.commands;

public class GAliasCommand extends GlobalShopCommand {
    @Override
    public String getCommandName() {
        return "g";
    }
}